public class Main {

    //variables

    //methods
    public static void main(String[] args) {
        // write your code here
        Platformer myApp = new Platformer();
        new Thread(myApp).run();

    }
}
